With this homebrew, through a simple menu you can choose what theme you want to install and interchange them rapidly and safely.

You can also add a preview in .PNG format with your own theme that will be showed on TOP_SCREEN (if the PNG is too big for the screen, it can be "explored" through Circle Pad).
